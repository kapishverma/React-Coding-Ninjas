import logo from './logo.svg';
import './App.css';

function App() {
  return (
      <p>Welcome to React Course on codingninjas.com</p>
  );
}

export default App;

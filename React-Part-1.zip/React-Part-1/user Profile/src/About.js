import { Component } from "react";

export default class About extends Component {
    render() {
        return (
            <>
                <div className="about">
                    <p>
                        Hi, my name is Kapish. I am a full stack web developer and  I have develope several projects with MERN stack. I am also familiar with JAVA and DSA.
                    </p>
                </div>
            </>
        )
    }
}

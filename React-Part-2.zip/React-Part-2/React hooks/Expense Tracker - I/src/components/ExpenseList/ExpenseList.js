import React, { useState } from "react";
import styles from "./ExpenseList.module.css";
import Transaction from "../Transaction/Transaction";

export default function ExpenseList(props) {
  return (
    <div className={styles.expenseListContainer}>
      <h3>Transactions</h3>
      <ul className={styles.transactionList}>
        {/* Display transactions here */}
        {props.transactionList.map((list, index) => {
          <Transaction list={list} index={index} />
        })}
      </ul>
    </div>
  );
}

import "./App.css";
import React, { useState } from "react";
import ExpenseForm from "./components/ExpenseForm/ExpenseForm";
import ExpenseInfo from "./components/ExpenseInfo/ExpenseInfo";
import ExpenseList from "./components/ExpenseList/ExpenseList";

export default function App() {
  // Create state for the expenses here
  const [grandTotal, setGrandTotal] = useState(123);
  const [transactionList, setTransactionList] = useState([]);
  const [expenses, setExpenses] = useState([]);

  const handleSetExpense = (text, amount) => {
    const newExpense = { text, amount };
    setExpenses((prevExpenses) => [...prevExpenses, newExpense]);
  };

  const handleSetTransactionList = (transaction) => {
    setTransactionList((prevTransactionList) => [...prevTransactionList, transaction]);
  };

  const handleSetGrandTotal = (value) => {
    setGrandTotal((prevGrandTotal) => prevGrandTotal + value);
  };

  return (
    <>
      <h2 className="mainHeading">Expense Tracker</h2>
      <div className="App">
        <ExpenseForm setExpense={handleSetExpense} />
        <div className="expenseContainer">
          <ExpenseInfo grandTotal={grandTotal} />
          <ExpenseList transactionList={transactionList} />
        </div>
      </div>
    </>
  );
}

import { useState, useReducer, useEffect } from "react";
import "./App.css";

// components imports
import ExpenseForm from "./components/ExpenseForm/ExpenseForm";
import ExpenseInfo from "./components/ExpenseInfo/ExpenseInfo";
import ExpenseList from "./components/ExpenseList/ExpenseList";

// react toasts
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// import firebase methods here
import { db } from "./components/firebase"
import { doc, collection, addDoc, updateDoc, deleteDoc } from "firebase/firestore";

const reducer = (state, action) => {
  const { payload } = action;
  switch (action.type) {
    case "ADD_EXPENSE": {
      return {
        expenses: [payload.expense, ...state.expenses]
      };
    }
    case "REMOVE_EXPENSE": {
      return {
        expenses: state.expenses.filter((expense) => expense.id !== payload.id)
      };
    }
    case "UPDATE_EXPENSE": {
      const expensesDuplicate = state.expenses;
      expensesDuplicate[payload.expensePos] = payload.expense;
      return {
        expenses: expensesDuplicate
      };
    }
    default:
      return state;
  }
};

function App() {
  console.log("App rendered"); // Add this line

  const [state, dispatch] = useReducer(reducer, { expenses: [] });
  const [expenseToUpdate, setExpenseToUpdate] = useState(null);

  // useEffect(() => {
  //   (async () => {
  //     console.log("useEffect")
  //     const querySnapshot = await getDocs(collection(db, "expenses"));
  //     querySnapshot.forEach((doc) => {

  //       dispatch({
  //         type: "ADD_EXPENSE",
  //         //~ add the new document id to the payload expense object below
  //         payload: { expense: { id: doc.id, ...doc.data() } }
  //       })
  //     })
  //   })();
  // }, [])

  const addExpense = async (expense) => {
    // add expense to firestore here

    const docRef = await addDoc(collection(db, "expenses"), expense);    //~ Add a new document with a generated id.
    // console.log("Document written with ID: ", docRef.id);

    dispatch({
      type: "ADD_EXPENSE",
      //~ add the new document id to the payload expense object below
      payload: { expense: { ...expense, id: docRef.id } }
    });
    toast.success("Expense added successfully.");
  };

  const deleteExpense = async (id) => {
    await deleteDoc(doc(db, "expenses", id));
    dispatch({ type: "REMOVE_EXPENSE", payload: { id } });
  };

  const resetExpenseToUpdate = () => {
    setExpenseToUpdate(null);
  };

  const updateExpense = async (expense) => {
    let expensePos = state.expenses.map(exp => exp.id).indexOf(expense.id)

    if (expensePos === -1) {
      return false;
    }

    // update expense in firestore here
    const docRef = await doc(db, "expenses", expense.id);

    await updateDoc(docRef, {
      text: expense.text,
      amount: expense.amount
    });

    dispatch({ type: "UPDATE_EXPENSE", payload: { expensePos, expense } });
    toast.success("Expense updated successfully.");
    return true;
  };

  return (
    <>
      <ToastContainer />
      <h2 className="mainHeading">Expense Tracker</h2>
      <div className="App">
        <ExpenseForm
          addExpense={addExpense}
          expenseToUpdate={expenseToUpdate}
          updateExpense={updateExpense}
          resetExpenseToUpdate={resetExpenseToUpdate}
        />
        <div className="expenseContainer">
          <ExpenseInfo expenses={state.expenses} />
          <ExpenseList
            expenses={state.expenses}
            deleteExpense={deleteExpense}
            changeExpenseToUpdate={setExpenseToUpdate}
          />
        </div>
      </div>
    </>
  );
}

export default App;

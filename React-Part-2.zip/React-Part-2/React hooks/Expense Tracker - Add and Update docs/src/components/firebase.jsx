// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyByYHGbCubbAXbb2C5t6YDML-3M2dBeuB0",
  authDomain: "expense-tracker-389c3.firebaseapp.com",
  databaseURL: "https://expense-tracker-389c3-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "expense-tracker-389c3",
  storageBucket: "expense-tracker-389c3.appspot.com",
  messagingSenderId: "12843705130",
  appId: "1:12843705130:web:553a308d112908439f3453"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
//~ Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app);